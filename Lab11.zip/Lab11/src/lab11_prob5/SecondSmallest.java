package lab11_prob5;

import java.util.List;

public class SecondSmallest{
public static <T extends Comparable<? super T>> T secondSmallest(List<T> list) {
    if (list == null || list.size() < 2) {
        throw new IllegalArgumentException("List must have at least 2 elements");
    }
    T min = list.get(0);
    T secondMin = list.get(1);
    if (min.compareTo(secondMin) > 0) {
        T tmp = min;
        min = secondMin;
        secondMin = tmp;
    }
    for (int i = 2; i < list.size(); i++) {
        T elem = list.get(i);
        if (elem.compareTo(min) < 0) {
            secondMin = min;
            min = elem;
        } else if (elem.compareTo(secondMin) < 0) {
            secondMin = elem;
        }
    }
    return secondMin;
}
}