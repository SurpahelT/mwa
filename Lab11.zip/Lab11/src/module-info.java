/**
 * 
 */
/**
 * @author suraphelayalew
 *
 */
module Lab11 {
}