package demo;

public class Example1Impl implements Example1 {

//	@Override
//	public void act() {
//		// TODO Auto-generated method stub
//		
//	}
	
	@Override
	public String toString(String s) {
		return null;
	}
	
}
