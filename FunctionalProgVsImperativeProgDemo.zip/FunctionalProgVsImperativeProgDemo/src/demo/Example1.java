package demo;

@FunctionalInterface
public interface Example1 {
	
	String toString(String s);
//	void act();
//	int sum();

}




