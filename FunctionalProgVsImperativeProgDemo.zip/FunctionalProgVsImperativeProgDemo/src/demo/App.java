package demo;

import java.util.List;
import java.util.function.Consumer;

public class App {

	public static void main(String[] args) {
		var names = List.of("Anna", "Bob", "Carlos", "Dave", "Ernie");
		
		// Print the list of names
		// Imperative programming
		// Classic for...loop
//		for(int i = 0; i < names.size(); i++) {
//			System.out.println(names.get(i));
//		}
		// Enhanced for... loop a.k.a for-each loop
//		for(String name : names) {
//			//
//		}
		
		// Functional programming style - Declarative
		//names.forEach(new NamePrintingConsumer());
		
//		Consumer<String> namePrintingConsumer = new Consumer<String>() {
//
//			@Override
//			public void accept(String t) {
//				System.out.println(t);	
//			}
//			
//		};
//		names.forEach(namePrintingConsumer);
		
		//final int i = 0;
		names.forEach(new Consumer<String>() {
			int i = 0;
			@Override
			public void accept(String t) {
				System.out.println(++i + "." + t);	
			}
		});
		
//		names.forEach((t) -> System.out.println(t));		
	}
}

//class NamePrintingConsumer implements Consumer<String> {
//
//	@Override
//	public void accept(String t) {
//		System.out.println(t);	
//	}
//	
//}
